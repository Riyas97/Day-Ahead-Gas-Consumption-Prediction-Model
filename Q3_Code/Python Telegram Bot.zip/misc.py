from datetime import datetime, timedelta
from dateutil import relativedelta
import logging

import matplotlib
import matplotlib.dates as mdates
from pandas.core.indexes.base import InvalidIndexError
from constant import *
import pandas as pd
import telegram
import time
import matplotlib.pyplot as plt
import seaborn as sns
import holidays
from sqlalchemy.engine.create import create_engine
from joblib import load
from copy import deepcopy
matplotlib.use('Agg')

sns.set_theme()
plt.ioff()

us_holidays = holidays.UnitedStates()
engine = create_engine(DB_URL)

def get_image_path(id):
    return f"./images/{id}.png"

def get_model_path(id):
    return load(f'./scalers/{id}.0_scaler.joblib')

# Gets the USER ID of the telegram user
def get_telegram_user(update):
    if update.message is not None:
        return str(update.message.from_user.id)
    elif update.callback_query is not None:
        return str(update.callback_query.from_user.id)
    return -1
    
# TODO
# Currently mapped to household 739
# Each telegram user will be mapped to a household
def get_household_user(telegram_id):
    logging.info(telegram_id)
    # return 35
    try :
        df = pd.read_sql_table(telegram_id, con=engine)
    except Exception:
        return -1 
    
    return df['dataid'].values[0]

def update_household_user(telegram_id, house_id):
    
    user_df = pd.DataFrame(columns=['dataid', 'telegram_id'])
    user_df = user_df.append({
        "dataid" : str(house_id),
        'telegram_id' : str(telegram_id)
    }, ignore_index=True)
    user_df.to_sql(str(telegram_id), con=engine, index=False , if_exists='replace')
      
def report_problem_households(house_id, problem):
    df = pd.read_sql_table(PROBLEMS, con=engine)
    df = df.append({
        "date" : datetime.now(),
        "house id" : house_id,
        "problem" : problem
    }, ignore_index=True)
    
    df.to_sql(PROBLEMS, con=engine, index=False, if_exists='replace')
    

# Gets the nearest day
def nearest_day():
    now = datetime.now()
    return 24 - now.hour

# Gets one day from now
def one_day_from_now():
    return 24

# Gets the nearest week 
def nearest_week():
    now = datetime.now()
    now = now.replace(second=0, microsecond=0, minute=0)
    hours = now.weekday() * 24 + now.hour
    return 24 * 7 - hours

# Gets one week from now
def one_week_from_now():
    return 24 * 7

# TODO
# Gets nearest month
def nearest_month():
    now = datetime.now()
    now = now.replace(second=0, microsecond=0, minute=0)
    hours = (now.day - 1) * 24 + now.hour
    logging.info(hours)
    return 30 * 24  - hours

# TODO
# Gets one month from now
def one_month_from_now():
    return 30 * 24 * 7

def split_minute_time(row):
    new_row = deepcopy(row)
    timestamp = row['localminute']
    
    new_row['weekday'] = timestamp.weekday()
    holiday_name = us_holidays.get(timestamp)
    
    if (holiday_name == None):
        new_row['is_holiday'] = 0
    else:
        new_row['is_holiday'] = 1

    if (new_row['weekday'] >= 5):
        new_row['is_weekday'] = 0
    else:
        new_row['is_weekday'] = 1

    if (timestamp.hour >= 9 and timestamp.hour <= 17):
        new_row['is_office_hour'] = 1
    else:
        new_row['is_office_hour'] = 0

    if (timestamp.hour >= 0 and timestamp.hour <= 9):
        new_row['is_sleeping'] = 1
    else:
        new_row['is_sleeping'] = 0

    new_row['month'] = timestamp.month
    new_row['year'] = timestamp.year
    new_row['date'] = timestamp.day
    new_row['hour'] = timestamp.hour
    time_difference = timestamp-datetime(year=2021, month=10, day=1)
    new_row['hours_passed'] = time_difference.seconds//3600 + time_difference.days * 24
    new_row['localminute'] = timestamp.replace(second=0, microsecond=0)
    return new_row

# TODO
# Creates a dataframe from start to end with the sampling interval
def get_samples(start, end, category=None):
    if (category == DAY):
        time_series = pd.date_range(start, end, freq='1H')
    elif (category == WEEK):
        time_series = pd.date_range(start, end, freq='24H')
    elif (category == MONTH):
        time_series = pd.date_range(start, end, freq='24H')
    else :
        return None
    df = pd.DataFrame(time_series, columns=['localminute'])  
    df = df.apply(lambda x : split_minute_time(x), axis=1)
    return df


# Gets the chat ID of the conversation
def get_chat_id(update, context):
    chat_id = -1
    if update.message is not None:
        chat_id = update.message.chat.id
    elif update.callback_query is not None:
        chat_id = update.callback_query.message.chat.id
    

    return chat_id

# Adds a delay function to the message to look realistic
def add_typing(update, context):
    if not LOCAL:
        context.bot.send_chat_action(
            chat_id=get_chat_id(update, context),
            action=telegram.ChatAction.TYPING,
            timeout=1,
        )
        time.sleep(1)
    else:
        return
    

# Plots the past consumption
def plot_consumption(df, save_path):
        
    fig = plt.figure(figsize=(20,10))
    ax = fig.add_subplot(111)
    ts = pd.to_datetime(df['localminute'])

    plt.plot_date(x=df['localminute'], y=df['meter_value'], linestyle='solid')
    plt.xlabel('Date')
    plt.ylabel('Gas Consumption')
    plt.title('Your household gas consumption')
    
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%d/%m/%y'))
    
    plt.savefig(save_path, dpi=300, bbox_inches='tight')    
    plt.close()

def plot_prediction_day(df, save_path):
    fig = plt.figure(figsize=(20,10))
    ax = fig.add_subplot(111)
    ts = pd.to_datetime(df['localminute'])

    plt.plot_date(ts, y=df['predicted_meter_value'], linestyle='solid')
    plt.xlabel('Date')
    plt.ylabel('Predicted Gas Consumption')
    # plt.xticks(rotation=20)
    plt.title('Your predicted household gas consumption')
    
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%d/%m/%y'))
    
    plt.savefig(save_path, dpi=300, bbox_inches='tight')    
    plt.close()

def plot_prediction_hour(df, save_path):
    fig = plt.figure(figsize=(20,10))
    ax = fig.add_subplot(111)
    ts = pd.to_datetime(df['localminute'])

    plt.plot_date(ts, y=df['predicted_meter_value'], linestyle='solid')
    plt.xlabel('Hour')
    plt.ylabel('Predicted Gas Consumption')
    plt.title('Your predicted household gas consumption')
    
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    
    plt.savefig(save_path, dpi=300, bbox_inches='tight')    
    plt.close()

