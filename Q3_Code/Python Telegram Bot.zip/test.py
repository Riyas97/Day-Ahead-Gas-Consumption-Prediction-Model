import joblib
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import datetime as dt
from datetime import datetime
import numpy as np
from functools import reduce
from sklearn.metrics import mean_squared_error as mse
from copy import deepcopy

from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.pipeline import make_pipeline
from joblib import dump, load

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from datetime import datetime


scaler = load('35.0_scaler.joblib')
checkpoint_path = "./checkpoints/" + str(house) +"/cp.ckpt"
checkpoint_dir = os.path.dirname(checkpoint_path)
cp_callback = tf.keras.callbacks.ModelCheckpoint(filepath=checkpoint_path,
                                            save_weights_only=True,
                                            verbose=0)


n_steps_in, n_steps_out = 24 * 7, 24 * 7
model = tf.keras.Sequential()
model.add(layers.LSTM( 168,return_sequences = True ,input_shape=(n_steps_in, n_features)))
model.add(layers.LSTM( 168))
model.add(layers.Dense(n_steps_out))
model.compile(optimizer='adam', loss='mse')
if os.path.exists(checkpoint_dir):
    model.load_weights(checkpoint_path).expect_partial()
    print("model loaded" + checkpoint_path)
x_input = np.asarray(scaled[24 * 28: 24* 35])
x_input = x_input.reshape((1, n_steps_in, n_features))
predictions = []
yhat = model.predict(x_input, verbose=0)
res = yhat

ADDITIONAL_WEEKS_TO_PREDICT = 3
for i in range(ADDITIONAL_WEEKS_TO_PREDICT):
    x_input = np.asarray(yhat)
    x_input = x_input.reshape((1, n_steps_in, n_features))
    yhat = model.predict(x_input, verbose=0)
    res = np.concatenate((yhat, res), axis=1)

predicted = pd.Series(scaler.inverse_transform(res)[0], pred_index )
predicted = predicted.cumsum() + house_df['meter_value'][24 * 35 - 1]

plt.figure(figsize=(12, 8))
# plt.plot(house_df.index[:24 * 21], scaled[:24* 21], c='blue' , linewidth=3)
plt.plot(test_index, house_df['meter_value'][24 * 28: 24* 35]  , c='orange' ,  label = 'test', linewidth=3)
plt.plot(pred_index[: len(house_df['meter_value'][24 * 35: 24 * 35 + 24 * 7 * (ADDITIONAL_WEEKS_TO_PREDICT + 1)] )], house_df['meter_value'][24 * 35: 24 * 35 + 24 * 7 * (ADDITIONAL_WEEKS_TO_PREDICT + 1)] , c='red' ,  label = 'actual', linewidth=1)
plt.plot(pred_index, predicted , c='green' ,  label = 'predicted', linewidth=1)


# plt.plot(test_df['meter_value'], test_df['mean_predicted_meter_value'], 'o' , c='black' ,  label = 'predicted mean test value', linewidth=3)
plt.xlabel('Actual Meter Value')
plt.ylabel('Predicted Meter Value')
plt.title(f'Household {house} \n')
# plt.title(f'Household {house} \nTesting SVR MSE : {mean_svr_squared_error}\nTesting LR MSE : {mean_lr_squared_error}\nEnsemble MSE : {true_mean_squared_error}')
plt.legend()
plt.show