import logging
import logging.config
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from joblib import dump, load
import requests
from datetime import datetime


url = 'https://comphilo-1577854701853.et.r.appspot.com/predict'

from telegram.ext import (
    Updater,
    CommandHandler,
    MessageHandler,
    Filters
)

from constant import *
from misc import *

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logger = logging.getLogger(__name__)


past_consumption = pd.read_csv('Past_data.csv', index_col='localminute', parse_dates=True, date_parser=lambda col: pd.to_datetime(col))
password_list = pd.read_csv('password_list.csv')
status_dict = dict()
house_dict = dict()


def check_consumption(update, context):
    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("You have not logged in. Please proceed to do so by typing /login.",
                              reply_markup=COMMANDS_KEYBOARD)
        return
    temp_file_save_path = f"./images/{house_id}.png"
    household_consumption = past_consumption[past_consumption['dataid'] == int(house_id)]
    now = datetime.now()
    household_consumption = household_consumption[household_consumption.index < str(now)]
    household_consumption = household_consumption.reset_index()

    plot_consumption(household_consumption, temp_file_save_path)
    context.bot.send_photo(chat_id=telegram_id,
                           photo=open(temp_file_save_path, 'rb'))

def get_daily_LSTM(update, context):
    n_steps_in, n_steps_out = 24 * 7, 24 * 7

    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("You have not logged in. Please proceed to do so by typing /login.",
                              reply_markup=COMMANDS_KEYBOARD)
        return
    context.bot.send_message(telegram_id, f'Trying to forecast, please hold on')
    scaler = get_model_path(house_id)
    
    household_consumption = past_consumption[past_consumption['dataid'] == int(house_id)]
    now = datetime.now()
    household_consumption = household_consumption[household_consumption.index < str(now)]

    diff = household_consumption['meter_value'].diff()
    test_series = diff[-24 * 7:]
    X_input =  scaler.transform(test_series.values.reshape(len(test_series), 1))
    X_input = X_input.reshape((1, n_steps_in, 1))

    data = {'house_id' : house_id,'arr' : X_input.tolist()}
    response = requests.post(url, json=data)
    res = (response.json())
    yhat = np.array(res['arr'])
    
    pred = yhat
    index = pd.date_range(test_series.index[0], periods=24 * 2 * 7, freq="H")
    test_index = index[:24 * 7]
    pred_index = index[24 * 7:]

    pred = pd.Series(scaler.inverse_transform(pred)[0], pred_index )
    pred = pred.cumsum() + household_consumption['meter_value'][-1]

    temp_file_save_path=get_image_path(house_id)
    plt.figure(figsize=(20,10))
    print(test_index.shape, household_consumption['meter_value'][-24 * 7:].shape, pred_index.shape, pred.shape )
    plt.plot(test_index, household_consumption['meter_value'][-24 * 7:]  , c='orange' ,  label = 'last week', linewidth=3)
    # print(pred_index[:24].shape, pred[:24].shape())
    hours = nearest_day()
    plt.plot(pred_index[:hours], pred[:hours] , c='green' ,  label = 'forecast', linewidth=3)
    plt.xlabel('Date')
    plt.ylabel('Meter Value')
    plt.savefig(temp_file_save_path, dpi=300, bbox_inches='tight')    
    plt.close()
    context.bot.send_photo(chat_id=telegram_id, photo=open(temp_file_save_path, 'rb'))
    gas_consumed = pred[:24].values.max() - pred[:24].values.min()
    price = gas_consumed * GAS_PRICE / 1000
    price = "{:.2f}".format(price)
    context.bot.send_message(telegram_id, f'Here is how much we estimate you will pay for this time frame:\nUSD$ {price}',
                              reply_markup=COMMANDS_KEYBOARD)    

def get_next_day_LSTM(update, context):
    n_steps_in, n_steps_out = 24 * 7, 24 * 7

    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("You have not logged in. Please proceed to do so by typing /login.",
                              reply_markup=COMMANDS_KEYBOARD)
        return
    context.bot.send_message(telegram_id, f'Trying to forecast, please hold on')
    scaler = get_model_path(house_id)
    
    household_consumption = past_consumption[past_consumption['dataid'] == int(house_id)]
    now = datetime.now()
    household_consumption = household_consumption[household_consumption.index < str(now)]

    diff = household_consumption['meter_value'].diff()
    test_series = diff[-24 * 7:]
    X_input =  scaler.transform(test_series.values.reshape(len(test_series), 1))
    X_input = X_input.reshape((1, n_steps_in, 1))

    data = {'house_id' : house_id,'arr' : X_input.tolist()}
    response = requests.post(url, json=data)
    res = (response.json())
    yhat = np.array(res['arr'])
    
    pred = yhat
    index = pd.date_range(test_series.index[0], periods=24 * 2 * 7, freq="H")
    test_index = index[:24 * 7]
    pred_index = index[24 * 7:]

    pred = pd.Series(scaler.inverse_transform(pred)[0], pred_index )
    pred = pred.cumsum() + household_consumption['meter_value'][-1]

    temp_file_save_path=get_image_path(house_id)
    plt.figure(figsize=(20,10))
    print(test_index.shape, household_consumption['meter_value'][-24 * 7:].shape, pred_index.shape, pred.shape )
    plt.plot(test_index, household_consumption['meter_value'][-24 * 7:]  , c='orange' ,  label = 'last week', linewidth=3)
    hours = one_day_from_now()
    plt.plot(pred_index[:hours], pred[:hours] , c='green' ,  label = 'forecast', linewidth=3)
    plt.xlabel('Date')
    plt.ylabel('Meter Value')
    plt.savefig(temp_file_save_path, dpi=300, bbox_inches='tight')    
    plt.close()
    context.bot.send_photo(chat_id=telegram_id, photo=open(temp_file_save_path, 'rb'))
    gas_consumed = pred[:24].values.max() - pred[:24].values.min()
    price = gas_consumed * GAS_PRICE / 1000
    price = "{:.2f}".format(price)
    context.bot.send_message(telegram_id, f'Here is how much we estimate you will pay for this time frame:\nUSD$ {price}',
                              reply_markup=COMMANDS_KEYBOARD)    

def get_weekly_LSTM(update, context):
    
    n_steps_in, n_steps_out = 24 * 7, 24 * 7

    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("You have not logged in. Please proceed to do so by typing /login.",
                              reply_markup=COMMANDS_KEYBOARD)
        return
    context.bot.send_message(telegram_id, f'Trying to forecast, please hold on')
    scaler = get_model_path(house_id)

    household_consumption = past_consumption[past_consumption['dataid'] == int(house_id)]
    now = datetime.now()
    household_consumption = household_consumption[household_consumption.index < str(now)]
    
    diff = household_consumption['meter_value'].diff()
    test_series = diff[-24 * 7:]
    X_input =  scaler.transform(test_series.values.reshape(len(test_series), 1))
    X_input = X_input.reshape((1, n_steps_in, 1))

    data = {'house_id' : house_id,'arr' : X_input.tolist()}
    response = requests.post(url, json=data)
    res = (response.json())
    yhat = np.array(res['arr'])

    pred = yhat
    
    index = pd.date_range(test_series.index[0], periods=24 * 7 * 2, freq="H")
    test_index = index[:24 * 7]
    pred_index = index[24 * 7:]

    pred = pd.Series(scaler.inverse_transform(pred)[0], pred_index )
    pred = pred.cumsum() + household_consumption['meter_value'][-1]

    temp_file_save_path=get_image_path(house_id)
    plt.figure(figsize=(20,10))
    print(test_index.shape, household_consumption['meter_value'][-24 * 7:].shape, pred_index.shape, pred.shape )
    plt.plot(test_index, household_consumption['meter_value'][-24 * 7:]  , c='orange' ,  label = 'last week', linewidth=3)
    hours = nearest_week()
    plt.plot(pred_index[:hours], pred[:hours] , c='green' ,  label = 'forecast', linewidth=3)
    plt.xlabel('Date')
    plt.ylabel('Meter Value')
    plt.savefig(temp_file_save_path, dpi=300, bbox_inches='tight')    
    plt.close()
    context.bot.send_photo(chat_id=telegram_id, photo=open(temp_file_save_path, 'rb'))
    gas_consumed = pred.values.max() - pred.values.min()
    price = gas_consumed * GAS_PRICE / 1000
    price = "{:.2f}".format(price)
    context.bot.send_message(telegram_id, f'Here is how much we estimate you will pay for this time frame:\nUSD$ {price}',
                              reply_markup=COMMANDS_KEYBOARD)
    
def get_next_week_LSTM(update, context):
        
    n_steps_in, n_steps_out = 24 * 7, 24 * 7

    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("You have not logged in. Please proceed to do so by typing /login.",
                              reply_markup=COMMANDS_KEYBOARD)
        return
    context.bot.send_message(telegram_id, f'Trying to forecast, please hold on')
    scaler = get_model_path(house_id)

    household_consumption = past_consumption[past_consumption['dataid'] == int(house_id)]
    now = datetime.now()
    household_consumption = household_consumption[household_consumption.index < str(now)]
    
    diff = household_consumption['meter_value'].diff()
    test_series = diff[-24 * 7:]
    X_input =  scaler.transform(test_series.values.reshape(len(test_series), 1))
    X_input = X_input.reshape((1, n_steps_in, 1))

    data = {'house_id' : house_id,'arr' : X_input.tolist()}
    response = requests.post(url, json=data)
    res = (response.json())
    yhat = np.array(res['arr'])

    pred = yhat
    
    index = pd.date_range(test_series.index[0], periods=24 * 7 * 2, freq="H")
    test_index = index[:24 * 7]
    pred_index = index[24 * 7:]

    pred = pd.Series(scaler.inverse_transform(pred)[0], pred_index )
    pred = pred.cumsum() + household_consumption['meter_value'][-1]

    temp_file_save_path=get_image_path(house_id)
    plt.figure(figsize=(20,10))
    print(test_index.shape, household_consumption['meter_value'][-24 * 7:].shape, pred_index.shape, pred.shape )
    plt.plot(test_index, household_consumption['meter_value'][-24 * 7:]  , c='orange' ,  label = 'last week', linewidth=3)
    hours = one_week_from_now()
    plt.plot(pred_index[:hours], pred[:hours] , c='green' ,  label = 'forecast', linewidth=3)
    plt.xlabel('Date')
    plt.ylabel('Meter Value')
    plt.savefig(temp_file_save_path, dpi=300, bbox_inches='tight')    
    plt.close()
    context.bot.send_photo(chat_id=telegram_id, photo=open(temp_file_save_path, 'rb'))
    gas_consumed = pred.values.max() - pred.values.min()
    price = gas_consumed * GAS_PRICE / 1000
    price = "{:.2f}".format(price)
    context.bot.send_message(telegram_id, f'Here is how much we estimate you will pay for this time frame:\nUSD$ {price}',
                              reply_markup=COMMANDS_KEYBOARD)
    
def get_monthly_LSTM(update, context):
    
    n_steps_in, n_steps_out = 24 * 7, 24 * 7

    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("You have not logged in. Please proceed to do so by typing /login.")
        return
    context.bot.send_message(telegram_id, f'Trying to forecast, please hold on')
    scaler = get_model_path(house_id)

    household_consumption = past_consumption[past_consumption['dataid'] == int(house_id)]
    now = datetime.now()
    household_consumption = household_consumption[household_consumption.index < str(now)]
    
    diff = household_consumption['meter_value'].diff()
    test_series = diff[-24 * 7:]
    X_input =  scaler.transform(test_series.values.reshape(len(test_series), 1))
    X_input = X_input.reshape((1, n_steps_in, 1))

    data = {'house_id' : house_id,'arr' : X_input.tolist()}
    response = requests.post(url, json=data)
    res = (response.json())
    yhat = np.array(res['arr'])
    
    pred = yhat

    ADDITIONAL_WEEKS_TO_PREDICT = 3
    for i in range(ADDITIONAL_WEEKS_TO_PREDICT):
        x_input = np.asarray(yhat)
        x_input = x_input.reshape((1, n_steps_in, 1))
        data = {'house_id' : house_id,'arr' : X_input.tolist()}
        response = requests.post(url, json=data)
        res = (response.json())
        yhat = np.array(res['arr'])
        pred = np.concatenate((pred, yhat), axis=1)


    index = pd.date_range(test_series.index[0], periods=24 * 7 * 5, freq="H")
    test_index = index[:24 * 7]
    pred_index = index[24 * 7:]

    pred = pd.Series(scaler.inverse_transform(pred)[0], pred_index )
    pred = pred.cumsum() + household_consumption['meter_value'][-1]


    temp_file_save_path=get_image_path(house_id)
    plt.figure(figsize=(20,10))
    print(test_index.shape, household_consumption['meter_value'][-24 * 7:].shape, pred_index.shape, pred.shape )
    plt.plot(test_index, household_consumption['meter_value'][-24 * 7:]  , c='orange' ,  label = 'last week', linewidth=3)
    hours = nearest_month()
    plt.plot(pred_index[:hours], pred[:hours] , c='green' ,  label = 'forecast', linewidth=3)
    plt.xlabel('Date')
    plt.ylabel('Meter Value')
    plt.savefig(temp_file_save_path, dpi=300, bbox_inches='tight')    
    plt.close()
    context.bot.send_photo(chat_id=telegram_id, photo=open(temp_file_save_path, 'rb'))

    gas_consumed = pred.values.max() - pred.values.min()
    price = gas_consumed * GAS_PRICE / 1000
    price = "{:.2f}".format(price)
    context.bot.send_message(telegram_id, f'Here is how much we estimate you will pay for this time frame:\nUSD$ {price}',
                              reply_markup=COMMANDS_KEYBOARD)

def get_next_month_LSTM(update, context):
    
    n_steps_in, n_steps_out = 24 * 7, 24 * 7

    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("You have not logged in. Please proceed to do so by typing /login.",
                              reply_markup=COMMANDS_KEYBOARD)
        return
    context.bot.send_message(telegram_id, f'Trying to forecast, please hold on')
    scaler = get_model_path(house_id)

    household_consumption = past_consumption[past_consumption['dataid'] == int(house_id)]
    now = datetime.now()
    household_consumption = household_consumption[household_consumption.index < str(now)]
    
    diff = household_consumption['meter_value'].diff()
    test_series = diff[-24 * 7:]
    X_input =  scaler.transform(test_series.values.reshape(len(test_series), 1))
    X_input = X_input.reshape((1, n_steps_in, 1))

    data = {'house_id' : house_id,'arr' : X_input.tolist()}
    response = requests.post(url, json=data)
    res = (response.json())
    yhat = np.array(res['arr'])
    
    pred = yhat

    ADDITIONAL_WEEKS_TO_PREDICT = 3
    for i in range(ADDITIONAL_WEEKS_TO_PREDICT):
        x_input = np.asarray(yhat)
        x_input = x_input.reshape((1, n_steps_in, 1))
        data = {'house_id' : house_id,'arr' : X_input.tolist()}
        response = requests.post(url, json=data)
        res = (response.json())
        yhat = np.array(res['arr'])
        pred = np.concatenate((pred, yhat), axis=1)


    index = pd.date_range(test_series.index[0], periods=24 * 7 * 5, freq="H")
    test_index = index[:24 * 7]
    pred_index = index[24 * 7:]

    pred = pd.Series(scaler.inverse_transform(pred)[0], pred_index )
    pred = pred.cumsum() + household_consumption['meter_value'][-1]


    temp_file_save_path=get_image_path(house_id)
    plt.figure(figsize=(20,10))
    print(test_index.shape, household_consumption['meter_value'][-24 * 7:].shape, pred_index.shape, pred.shape )
    plt.plot(test_index, household_consumption['meter_value'][-24 * 7:]  , c='orange' ,  label = 'last week', linewidth=3)
    plt.plot(pred_index, pred , c='green' ,  label = 'forecast', linewidth=3)
    plt.xlabel('Date')
    plt.ylabel('Meter Value')
    plt.savefig(temp_file_save_path, dpi=300, bbox_inches='tight')    
    plt.close()
    context.bot.send_photo(chat_id=telegram_id, photo=open(temp_file_save_path, 'rb'))

    gas_consumed = pred.values.max() - pred.values.min()
    price = gas_consumed * GAS_PRICE / 1000
    price = "{:.2f}".format(price)
    context.bot.send_message(telegram_id, f'Here is how much we estimate you will pay for this time frame:\nUSD$ {price}',
                              reply_markup=COMMANDS_KEYBOARD)

    
def report_problem(update, context):
    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("You have not logged in. Please proceed to do so by typing /login.",
                              reply_markup=COMMANDS_KEYBOARD)
        return
    
    update.message.reply_text("What problem would you like to report?")
    status_dict[telegram_id] = ERROR


def message_handler(update, context):
    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    user_answer = update.message.text
    logging.info(f"User answer : {user_answer}")
    if (house_id == -1):
        if (status_dict[telegram_id] == HOUSE_ID):
            try : 
                user_answer = int(user_answer)
            except Exception:
                update.message.reply_text("Please give your house id as a number.")
                return
            
            if (len(password_list[password_list['dataid'] == user_answer]) == 0):
                update.message.reply_text("Your household is not registered with us.",
                              reply_markup=COMMANDS_KEYBOARD)
                return
            else:
                update.message.reply_text("What is your password?")
                house_dict[telegram_id] = user_answer
                status_dict[telegram_id] = PASSWORD
                return
            
        elif (status_dict[telegram_id] == PASSWORD):
            user_house = house_dict[telegram_id]
            
            house_pw = password_list[password_list['dataid'] == user_house]['password']
            if (user_answer in house_pw.values):
                update_household_user(telegram_id, user_house)
                update.message.reply_text("You have been logged in.",
                              reply_markup=COMMANDS_KEYBOARD)
                status_dict[telegram_id] = CLEAR
                return
            else:
                update.message.reply_text("That is not the correct password. Please key in your password again.")
                
    else:
        if (status_dict[telegram_id] == ERROR):
            report_problem_households(house_id, user_answer)
            update.message.reply_text("Your problem has been directed to us. We will attempt to resolve the problem on our end in 2-3 working days.",
                              reply_markup=COMMANDS_KEYBOARD)
            status_dict[telegram_id] = CLEAR
            return

def login_handler(update, context):
    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id != -1):
        update.message.reply_text("Hey there, you are already logged in!",
                              reply_markup=COMMANDS_KEYBOARD)
    else:
        status_dict[telegram_id] = HOUSE_ID
        update.message.reply_text("Hey there, what is your house id?")

def logout_handler(update, context):
    telegram_id = get_telegram_user(update)
    house_id = get_household_user(telegram_id)
    if (house_id == -1):
        update.message.reply_text("Hey there, you are already logged out!",
                              reply_markup=COMMANDS_KEYBOARD)
    else:
        df = pd.read_sql_table(telegram_id, con=engine)
        df.iloc[0]['dataid'] = -1
        df.to_sql(telegram_id, con=engine, index=False , if_exists='replace')
        update.message.reply_text("Logged out!",
                              reply_markup=COMMANDS_KEYBOARD)

def help_handler(update, context):
    update.message.reply_text('Check out the various functions below to start your Smart Home Experience!',
                              reply_markup=COMMANDS_KEYBOARD)

def error_handler(update, context):
    error = f'Update {update} caused error {context.error}'
    logger.warning(error)


def main():
    if (LOCAL):
        updater = Updater(LOCAL_TOKEN, use_context=True)
    else:
        updater = Updater(TOKEN, use_context=True)

    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", help_handler))
    dp.add_handler(CommandHandler("login", login_handler))
    dp.add_handler(CommandHandler('logout', logout_handler))
    dp.add_handler(CommandHandler("help", help_handler))
    dp.add_handler(CommandHandler("check_consumption", check_consumption))
    dp.add_handler(CommandHandler("get_daily", get_daily_LSTM))
    dp.add_handler(CommandHandler("get_next_day", get_next_day_LSTM))
    dp.add_handler(CommandHandler("get_weekly", get_weekly_LSTM))
    dp.add_handler(CommandHandler("get_next_week", get_next_week_LSTM))
    dp.add_handler(CommandHandler("get_monthly", get_monthly_LSTM))
    dp.add_handler(CommandHandler("get_next_month", get_next_month_LSTM))
    dp.add_handler(CommandHandler("report_problem", report_problem))
    dp.add_handler(MessageHandler(Filters.text, message_handler))
    dp.add_error_handler(error_handler)

    if (LOCAL):
        updater.start_polling()
    else:
        updater.start_webhook(listen="0.0.0.0",
                              port=int(PORT),
                              url_path=TOKEN,
                              webhook_url=f'https://pecan-street-project.herokuapp.com/{TOKEN}')

    updater.idle()

main()
