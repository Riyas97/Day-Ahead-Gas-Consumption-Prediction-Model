import pandas as pd
from constant import *
from sqlalchemy.engine.create import create_engine
from datetime import datetime

engine = create_engine(DB_URL)

df = pd.read_sql_table(PROBLEMS, con=engine)
df.to_csv("Errors.csv", index=False)