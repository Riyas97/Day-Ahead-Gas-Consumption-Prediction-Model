import pandas as pd
from sqlalchemy.engine.create import create_engine
from constant import *

ID = "380250195"
engine = create_engine(DB_URL)

df = pd.read_sql_table(ID, con=engine)

df.iloc[0]['dataid'] = -1

df.to_sql(ID, con=engine, index=False , if_exists='replace')