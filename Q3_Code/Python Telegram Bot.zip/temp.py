import pandas as pd
import numpy as np
from dateutil.relativedelta import relativedelta
from datetime import datetime, tzinfo

df = pd.read_csv('Past_data.csv', index_col='localminute', parse_dates=True, date_parser=lambda col: pd.to_datetime(col))
df.index = pd.to_datetime(df.index)

now = datetime.now()
df = df.loc[df.index < str(now)]
print(df)